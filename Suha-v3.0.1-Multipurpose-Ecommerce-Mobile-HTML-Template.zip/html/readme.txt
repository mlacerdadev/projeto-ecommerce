=====================================================================================
:: BEFORE GETTING STARTED A PWA READY TEMPLATE YOU NEED TO KNOW VERY SIMPLE THING! ::
=====================================================================================
PWA (Progressive Web App) mainly works with the "service-worker.js" file. This file cache data in your browser for smoothly viewing this website when you're offline.

:: What is the problem with that?
- When you edited the files & script and save it, your changes won't take effect until clear your browser cache.

:: How to solve this problem?
- Please disconnect from "service-worker.js" when you developing your site. Search for "service-worker.js" and comment on all JS codes or remove this file another location.
https://prnt.sc/tuwnua
https://prnt.sc/tuwo66

After completing the site developing, when you ready to go upload server. Now connect this file with your project.

======================
:: PWA Requirements ::
======================
The web site to be served from a secure (HTTPS) domain